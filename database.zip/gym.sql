-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 23, 2016 at 11:53 AM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gym`
--

-- --------------------------------------------------------

--
-- Table structure for table `attr`
--

CREATE TABLE `attr` (
  `id` int(11) NOT NULL,
  `image` varchar(200) NOT NULL,
  `name` varchar(300) NOT NULL,
  `rating` int(11) NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `attr`
--

INSERT INTO `attr` (`id`, `image`, `name`, `rating`, `description`) VALUES
(1, 'da.jpg', 'Trenka', 12, ''),
(2, 'yoga.jpg', 'Bauka', 45, 'asdfasf'),
(3, '6.jpg', 'Tracer', 8, 'Pull in, push up '),
(4, '5.jpg', 'Trap exercises', 10, 'Type: Strength\r\nMain Muscle Worked: Shoulders\r\nOther Muscles: Shoulders,Upper Trapezius,Levator Scapulae\r\nEquipment: Barbell\r\nMechanics Type: Compound'),
(5, '6.jpg', 'Treadmill', 9, 'Type: Cardio\r\nMain Muscle Worked: Quadriceps\r\nOther Muscles: Calves, Glutes, Hamstrings\r\nEquipment: Machine\r\nMechanics Type: N/A');

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE `people` (
  `id` int(11) NOT NULL,
  `name` varchar(240) NOT NULL,
  `phoneN` varchar(200) NOT NULL,
  `data` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`id`, `name`, `phoneN`, `data`) VALUES
(1, 'Rustem', '87788123', '123.123.123  15:00'),
(2, 'bauka', '8787878', '123,123.123  10:00'),
(3, 'bauka', '767667', '12.321.31  16:00'),
(4, 'bauka', '87781018880', '12.23.43  13:00'),
(5, 'bauka', '87788123', '12.06.16  18:00'),
(6, 'bauka', '8777-777-77-77', '12.11.16  15:00'),
(7, 'bauka', '87781019990', '12.21.12  10:00'),
(8, 'bauka', '999999888', '12.12.12  13:00'),
(9, 'bauka', '12.123.12', '43.34.34  14:00'),
(10, 'bauka', '8992.123.', '877381.1221  14:00'),
(19, 'bauka', '231', '123  13:00'),
(21, 'Ainur', '87781018880', '12.11.16  17:00');

-- --------------------------------------------------------

--
-- Table structure for table `price`
--

CREATE TABLE `price` (
  `id` int(11) NOT NULL,
  `price1` int(11) NOT NULL,
  `price2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `price`
--

INSERT INTO `price` (`id`, `price1`, `price2`) VALUES
(1, 1200, 300);

-- --------------------------------------------------------

--
-- Table structure for table `users2`
--

CREATE TABLE `users2` (
  `id` int(255) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users2`
--

INSERT INTO `users2` (`id`, `name`, `pass`, `email`, `phone`) VALUES
(1, 'admin', 'admin', 'bauka1.9.9.7@mail.ru', '87023837080'),
(2, 'max_9700', 'qwerty123', 'a.maks97@mail.ru', '87027837080'),
(13, 'adads', 'adasd', 'a.maks97@mail.ru', '87023837080'),
(14, 'SDFSDf', 'sdfsdf', 'sdfsdf', 'sdfsdf'),
(15, 'admin', '2222222', 'ssss', 'Ssss'),
(20, 'bauka', '1234', 'bauka1.9.9.7@mail.ru', '123'),
(21, 'Sauka', 'qwert', 'bauka1.9.9.7@mail.ru', '87781018880'),
(22, 'df', 'df', 'df@df.df', 'df'),
(23, 'dastan', '123', 'dastan@mail.ru', '1234567'),
(24, 'Rustem', '123', 'rustem@gmail.com', '123'),
(25, 'Ainur', 'ainur', 'ainur@mail.ru', '87012222222');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attr`
--
ALTER TABLE `attr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `price`
--
ALTER TABLE `price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users2`
--
ALTER TABLE `users2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `people`
--
ALTER TABLE `people`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `price`
--
ALTER TABLE `price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users2`
--
ALTER TABLE `users2`
  MODIFY `id` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
